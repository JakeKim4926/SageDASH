---
name: sagedash-ui
description: SAGEDash 프로젝트의 UI 디자인 시스템, 레이아웃 구조, 색상 팔레트, 컴포넌트 규격을 정의하는 skill. SAGEDash의 UI 구현, 화면 설계, 목업 제작, MFC View/Pane 디자인, WebView2 화면 설계 시 이 skill을 참조한다. "SAGEDash UI", "SAGEDash 화면", "SAGEDash 디자인", "SAGEDash 레이아웃", "SAGEDash 목업", "SAGEDash Pane", "SAGEDash WebView2 화면" 등이 언급되면 이 skill을 트리거한다.
---

# SAGEDash UI 디자인 시스템

## 디자인 방향

SAGEDash의 UI는 **ERP급 업무 도구**의 밀도감과 기능성을 갖추되,
**화이트 / 아이보리 / 실버** 톤의 깔끔하고 눈이 편한 색감을 유지한다.

### 핵심 원칙
- **업무 도구 밀도**: 정보가 빽빽하되 정돈되어 있어야 한다. 빈 공간이 과하면 안 된다.
- **시각적 위계**: 프레임 > 패널 > 콘텐츠 영역이 색상과 테두리로 명확히 구분되어야 한다.
- **아이콘 + 라벨**: 툴바, 네비게이터, 탭 등은 반드시 아이콘과 텍스트를 함께 사용한다.
- **데이터 그리드 중심**: 중앙 영역의 데이터 그리드가 시각적 주인공이다.
- **MFC 네이티브 톤**: Windows 네이티브 앱 느낌의 프레임, 툴바, 상태바 톤을 유지한다.

### 하이브리드 UI 일관성 원칙
- MFC 셸은 네이티브 Windows 업무 도구 톤을 유지한다.
- WebView2 콘텐츠는 동일한 색상 토큰, 타이포그래피, 간격 규칙을 공유하되, 카드/차트/요약 UI에 한해 웹 렌더링의 장점을 활용한다.
- MFC와 WebView2는 **"동일하게 보이는 것"보다 "같은 시스템에 속해 보이는 것"**을 목표로 한다.
- 두 세계의 차이가 불가피한 부분(폰트 렌더링, 안티앨리어싱, 서브픽셀 차이)은 허용하되, 색상 토큰과 간격 스케일은 반드시 공유한다.

### 다국어 지원 (한/영)
- UI는 **한국어와 영어 두 가지 로케일**을 지원한다.
- 모든 사용자 노출 문자열은 **하드코딩하지 않고 문자열 테이블(String Table)에서 로드**한다.
- MFC 구현 시 리소스 파일(`.rc`)의 String Table을 사용하며, 로케일별 리소스 DLL 또는 조건부 로드로 전환한다.
- WebView2 화면에서는 JSON 기반 로케일 파일(`locale/ko.json`, `locale/en.json`)을 사용한다.
- **코드 내에 한국어/영어 문자열을 직접 쓰지 않는다.** 반드시 문자열 ID로 참조한다.
- 레이아웃은 한국어/영어 모두 깨지지 않아야 한다. 영어 기준으로 너비를 잡되, 한국어 조합형 문자의 세로 정렬도 확인한다.
- 로케일 전환은 앱 설정에서 가능하며, Phase 1~2에서는 재시작 필요를 허용한다.

### 안티 패턴
- 웹앱처럼 너무 넓은 여백, 둥근 카드, 큰 폰트
- 다크 테마 (Phase 6 이전에는 고려하지 않는다)
- 과한 색상 사용 (액센트는 1가지, 시맨틱 3가지만 사용)
- 아이콘 없는 텍스트만의 툴바/네비게이터
- UI 문자열을 코드에 하드코딩하는 것

---

## 색상 팔레트

### 프레임/크롬 계열
| 토큰 | HEX | 용도 |
|------|-----|------|
| `frame-hi` | `#EDEBE7` | 프레임 그래디언트 상단, 툴바 배경 |
| `frame` | `#E4E2DD` | 프레임 기본, 탭 바 배경 |
| `frame-lo` | `#D8D5CF` | 프레임 그래디언트 하단 |
| `frame-border` | `#C8C4BC` | 프레임/툴바 테두리 |

### 패널/표면 계열
| 토큰 | HEX | 용도 |
|------|-----|------|
| `surface` | `#F4F2EE` | 패널 배경, 뷰 헤더 |
| `surface-alt` | `#E9E7E2` | 그리드 헤더, 교차행 대안 |
| `white` | `#FDFCFA` | 데이터 영역, 로그 영역 |
| `cream` | `#F9F8F5` | 버튼 배경, 교차행(stripe) |

### 텍스트 계열
| 토큰 | HEX | 용도 |
|------|-----|------|
| `text` | `#2A2926` | 본문, 제목, 데이터 값 |
| `text-mid` | `#5C5850` | 메뉴 항목, 로그 메시지 |
| `text-dim` | `#8A857C` | 보조 정보, 섹션 헤더, 그리드 컬럼 헤더 |
| `text-ghost` | `#B0ACA4` | 비활성 항목, 행 번호, 타임스탬프 |
| `text-muted` | `#CBC7C0` | 비활성 아이콘, placeholder |

### 액센트
| 토큰 | HEX | 용도 |
|------|-----|------|
| `accent` | `#4A6D8C` | 활성 탭 인디케이터, 선택 행 배경, 로그 INFO |
| `accent-light` | `#E3EBF2` | 네비게이터 활성 항목 배경 |
| `accent-dark` | `#35536C` | 액센트 텍스트, 활성 탭 라벨 |
| `selection` | `#D4E3F0` | 그리드 행 선택 배경 |
| `selection-border` | `#9BBAD4` | 그리드 행 선택 테두리 |

### 시맨틱
| 토큰 | HEX | 용도 |
|------|-----|------|
| `error` | `#B84840` | 에러 텍스트, 에러 dot |
| `error-bg` | `#FAEEEC` | 에러 행 배경 |
| `success` | `#5E8548` | 성공 텍스트, OK dot |
| `success-bg` | `#EEF3EA` | 성공 배경 |
| `warning` | `#A07E28` | 경고 텍스트, WARN 라벨 |
| `warning-bg` | `#F7F2E4` | 경고 배경 |

### 테두리
| 토큰 | HEX | 용도 |
|------|-----|------|
| `border` | `#D8D5CE` | 주요 패널 구분선 |
| `border-light` | `#E5E2DC` | 그리드 행 구분선, 가벼운 구분 |

### 상태 우선순위
하나의 요소에 여러 상태가 동시에 적용될 때 아래 우선순위에 따라 표현을 결정한다.

1. default
2. hover
3. selected
4. warning
5. error
6. disabled

예시:
- 행이 **에러 + 선택 상태**이면 `error-bg`를 유지하고 `selection-border`를 추가한다.
- `disabled` 상태는 항상 최우선이며, 다른 상태 표현을 덮어쓴다.

---

## 간격(Spacing) 시스템

모든 간격은 아래 스케일에서만 사용한다.

### Spacing Scale
| 토큰 | 값 | 비고 |
|------|----|------|
| `space-2` | 2px | 미세 조정 |
| `space-4` | 4px | 최소 간격 |
| `space-6` | 6px | 아이콘-텍스트, 라벨-값 |
| `space-8` | 8px | 기본 패딩, 그룹 간 간격 |
| `space-12` | 12px | 섹션 간 간격 |
| `space-16` | 16px | 큰 구분, 강조 패딩 |

### 적용 규칙
| 용도 | 간격 |
|------|------|
| Pane 내부 패딩 | `space-8` ~ `space-12` |
| 섹션 간 수직 간격 | `space-12` |
| 섹션 헤더 아래 간격 | `space-8` |
| 라벨과 값 사이 수직 간격 | `space-2` |
| 아이콘과 텍스트 사이 수평 간격 | `space-6` |
| 버튼 간 수평 간격 | `space-4` |
| 버튼 그룹 간 간격 | `space-8` |
| 그리드 셀 내부 패딩 | 수직 `space-4` / 수평 `space-12` |
| Properties 속성 행 간 간격 | `space-8` |
| Summary 카드 간 간격 | `space-8` |
| Navigator 항목 간 간격 | `space-2` |

---

## 전체 레이아웃 구조

SAGEDash 메인 윈도우는 **9개 영역**으로 구성된다.

```text
┌─────────────────────────────────────────────────┐
│ 1. Title Bar                                    │
├─────────────────────────────────────────────────┤
│ 2. Menu Bar                                     │
├─────────────────────────────────────────────────┤
│ 3. Toolbar (아이콘 + 라벨, 그룹 구분)           │
├─────────────────────────────────────────────────┤
│ 4. MDI Document Tabs                            │
├────────┬──────────────────────────┬─────────────┤
│        │                          │             │
│ 5.     │ 6. Center View           │ 7.          │
│ Nav    │    (Data Grid /          │ Properties  │
│ Panel  │     Mapping /            │ Panel       │
│ 184px  │     Validation)          │ 200px       │
│        │                          │             │
├────────┴──────────────────────────┴─────────────┤
│ 8. Output / Log Pane (Output, Log, Errors)      │
├─────────────────────────────────────────────────┤
│ 9. Status Bar                                   │
└─────────────────────────────────────────────────┘
```

### 배치 모델
- 수평 3단 구조: Navigator + Center View + Properties
- Navigator, Properties는 기본 너비 고정 + 사용자 리사이즈 가능
- Center View는 남은 공간을 모두 차지한다
- 상단 크롬은 고정 높이, Output Pane은 기본 높이 고정 + 리사이즈 가능

### 패널별 크기 정책
| 영역 | 기본 크기 | 최소 크기 | 리사이즈 | 접기/숨기기 |
|------|-----------|-----------|----------|-------------|
| Title Bar | OS 기본 | 고정 | 불가 | 불가 |
| Menu Bar | 28px 높이 | 고정 | 불가 | 불가 |
| Toolbar | 30px 높이 | 고정 | 불가 | View 메뉴에서 토글 |
| MDI Tabs | 26px 높이 | 고정 | 불가 | 불가 |
| Navigator | 184px 너비 | 120px | 가능 | 가능 |
| Center View | 나머지 전체 | 300px 너비 | 자동 확장 | 불가 |
| Properties | 200px 너비 | 140px | 가능 | 가능 |
| Output Pane | 120px 높이 | 72px | 가능 | 가능 |
| Status Bar | 24px 높이 | 고정 | 불가 | View 메뉴에서 토글 |

### 접기(Collapse) 동작
- Navigator, Properties, Output Pane은 접기 버튼 또는 더블클릭으로 접을 수 있다
- 접힌 패널은 가장자리에 아이콘 탭 상태로 남는다
- 접힌 공간은 Center View가 흡수한다
- MFC 구현 시 CDockablePane 오토하이드 또는 ShowPane(FALSE) 계열을 사용한다

### 최소 윈도우 크기
- 전체 윈도우 최소 크기: 800 × 600
- CMainFrame::OnGetMinMaxInfo에서 제한한다

### 해상도별 기본 레이아웃
| 해상도 | Navigator | Properties | Output Pane | 비고 |
|--------|-----------|------------|-------------|------|
| 1920×1080 이상 | 184px 표시 | 200px 표시 | 120px 표시 | 기본 전체 표시 |
| 1366×768 | 184px 표시 | 200px 표시 | 100px 표시 | Output 약간 축소 |
| 1280×720 이하 | 접기 권장 | 접기 권장 | 72px 최소 | Center View 우선 |

### 그리드 내부 동적 배치
- 컬럼 너비는 초기 자동 맞춤 후 사용자가 조절 가능
- 마지막 컬럼은 남은 공간을 채우는 방식(fill-last)을 우선한다
- 수평/수직 스크롤은 데이터 크기에 따라 자동 표시한다
- 행 번호 열은 32px을 기준으로 설계한다

> **구현 참고**: Phase 1~2의 기본 구현은 CListCtrl Report 모드로 시작하되,
> 고정 행 번호 열, 고급 셀 상태 렌더링, 완전한 fill-last, 셀 단위 세부 스타일링 등은
> 커스텀 그리드 도입 시 완전 적용한다.

---

## 영역별 규격

### 1. Title Bar
- 기본은 OS 기본 타이틀 바를 사용한다
- 앱 아이콘, 앱명, 현재 문서명은 타이틀 텍스트 수준에서 반영한다
- 커스텀 크롬(non-client 영역 커스터마이징)은 Phase 6 이전에는 도입하지 않는다
- 타이틀 포맷: `SAGEDash — {문서명}`

### 2. Menu Bar
- 높이: 28px
- 배경: `surface`
- 항목: File, Edit, View, Automation, Tools, Window, Help
- 폰트: 12px, `text-mid`

### 3. Toolbar
- 높이: 30px
- 배경: `frame-hi` → `frame`
- 버튼 구조: 아이콘(13×13) + 라벨(11px)
- 아이콘-라벨 간격: `space-6`
- 버튼 간 간격: `space-4`
- 그룹 간 간격: `space-8`
- 그룹 구성:
  - File: Open, Save
  - Data: Mapping, Validate, Export
  - Run: Batch, Schedule

### 4. MDI Document Tabs
- 높이: 26px
- 배경: `frame`
- 활성 탭: `white` 배경, `frame-border` 테두리
- 탭 구조: 파일 아이콘 + 파일명 + 닫기 버튼

### 5. Navigator Panel
- 너비: 184px
- 배경: `surface`
- 내부 패딩: `space-8` ~ `space-12`
- 섹션 헤더: 10px uppercase, `text-dim`
- 항목: 12px, 아이콘 14×14
- 활성 항목: `accent-light` 배경 + `accent-dark` 텍스트
- 항목 간 간격: `space-2`

### 6. Center View
- 배경: `white`
- 뷰 헤더 패딩: `space-6` / `space-12`
- 그리드 헤더: 11px 600, `surface` → `surface-alt`
- 그리드 셀: 12px, 내부 패딩 `space-4` / `space-12`
- 행 번호 열: 32px
- 교차행(stripe): `cream`
- 숫자 열: 우측 정렬
- 날짜 열: `text-dim`

### 7. Properties Panel
- 너비: 200px
- 배경: `surface`
- 내부 패딩: `space-8`
- 라벨-값 간격: `space-2`
- 속성 행 간 간격: `space-8`
- Summary 카드 간 간격: `space-8`

### 8. Output / Log Pane
- 탭 바: `surface`
- 로그 영역: `white`
- 패딩: `space-6` / `space-12`
- 로그 줄 높이: 18px
- 자동 스크롤: 기본 ON
- 최대 보존 줄 수: 5000
- Errors 탭: ERROR/WARN 필터 목록

### 9. Status Bar
- 높이: 24px
- 배경: `frame-hi` → `frame`
- 상태 dot + 텍스트 간격: `space-6`
- 우측 정보 항목 간 간격: `space-16`

---

## 컴포넌트 상태(State) 정의

모든 인터랙티브 컴포넌트는 다음 상태를 가진다.

| 상태 | 설명 |
|------|------|
| default | 기본 상태 |
| hover | 마우스 오버 |
| pressed | 클릭 중 |
| focused | 키보드 포커스 |
| disabled | 비활성 |
| error | 입력값 오류 |
| readonly | 읽기 전용 |

### Toolbar Button
| 상태 | 배경 | 테두리 | 텍스트 | 아이콘 |
|------|------|--------|--------|--------|
| default | `cream` → `surface` | `border` | `text-mid` | `text-dim` |
| hover | `white` | `border` | `text` | `text-mid` |
| pressed | `surface-alt` | `frame-border` | `text` | `text-mid` |
| disabled | `surface` | `border-light` | `text-muted` | `text-muted` |

### Navigator Item
| 상태 | 배경 | 텍스트 | 아이콘 |
|------|------|--------|--------|
| default | 투명 | `text-mid` | `text-dim` |
| hover | `border-light` | `text` | `text-mid` |
| active | `accent-light` | `accent-dark` | `accent` |
| disabled | 투명 | `text-muted` | `text-muted` |

### Grid Row / Cell
| 상태 | 배경 | 텍스트 | 테두리 |
|------|------|--------|--------|
| default | `white` | `text` | `border-light` |
| stripe | `cream` | `text` | `border-light` |
| hover | `rgba(74,109,140,0.05)` | `text` | `border-light` |
| selected | `selection` | `text` | `selection-border` |
| error | `error-bg` | `text` / 에러 셀 `error` | `border-light` |
| error + selected | `error-bg` | `text` / 에러 셀 `error` | `selection-border` |

### Edit
| 상태 | 배경 | 테두리 | 텍스트 |
|------|------|--------|--------|
| default | `white` | `border` | `text` |
| hover | `white` | `frame-border` | `text` |
| focused | `white` | `accent` | `text` |
| disabled | `surface` | `border-light` | `text-ghost` |
| error | `white` | `error` | `text` |
| readonly | `surface` | `border-light` | `text-mid` |

### ComboBox
| 상태 | 배경 | 테두리 | 텍스트 | 화살표 |
|------|------|--------|--------|--------|
| default | `white` | `border` | `text` | `text-dim` |
| hover | `white` | `frame-border` | `text` | `text-mid` |
| focused/open | `white` | `accent` | `text` | `accent` |
| disabled | `surface` | `border-light` | `text-ghost` | `text-muted` |

---

## Empty / Loading / Error 상태

### Empty 상태
- 데이터 없음 시 `COMMON_EMPTY`를 표시한다
- 중앙 정렬, `text-ghost`
- 기존 레이아웃 구조는 유지한다

### Loading 상태
- 상태바에 진행 메시지를 표시한다
- Center View는 기존 데이터가 있으면 유지하고, 없으면 로딩 메시지 또는 스켈레톤 대체 표시를 허용한다

### Filter Empty 상태
- 필터 결과가 없을 경우 "일치하는 항목 없음" 계열 메시지를 표시한다
- Navigator, Properties, Output Pane 구조는 유지한다

### Error 상태
- WebView2 로드 실패 시 네이티브 fallback 메시지와 재시도 액션을 제공한다
- 파싱 실패 시 Output/Log Pane과 상태바 모두에 실패 상태를 반영한다

---

## Phase별 UI 활성화 범위

### Phase 1
- **활성**: Title Bar, Menu Bar, Toolbar(File 그룹만), MDI Tabs, Center Data Grid, Output Pane, Status Bar
- **표시만**: Navigator(Input만 활성), Properties(기본 파일 정보만)
- **비활성**: Toolbar Data/Run 그룹, Navigator의 Mapping~Actions, 검색/필터

### Phase 2
- **추가 활성**: Navigator 전체, Properties Summary 카드, XLSX 관련 표시, 검색/필터

### Phase 3
- **추가 활성**: Toolbar Data 그룹, Navigator Pipeline 단계 전체, Center View 전환(Grid / Mapping / Validation), Edit / ComboBox

### Phase 4+
- WebView2 호스트가 특정 Pane 또는 View를 대체
- Dashboard / Reports 화면 도입
- MFC 셸은 외곽 프레임 유지

---

## 타이포그래피

| 용도 | 폰트 | 크기 | Weight | 비고 |
|------|------|------|--------|------|
| 본문/데이터 | Segoe UI | 12px | 400 | |
| 섹션 라벨 | Segoe UI | 10px | 600 | uppercase |
| 뷰 제목 | Segoe UI | 12px | 600 | |
| 그리드 헤더 | Segoe UI | 11px | 600 | |
| 툴바 버튼 | Segoe UI | 11px | 500 | |
| 메뉴 항목 | Segoe UI | 12px | 400 | |
| 상태바 | Segoe UI | 11px | 400 | |
| 로그 | Cascadia Code / Consolas | 11px | 400 | 모노스페이스 |
| 뱃지/카운트 | Segoe UI | 9~10px | 500~600 | |

---

## 아이콘 규격

- 툴바 아이콘: 13×13px
- 네비게이터 아이콘: 14×14px
- 탭 아이콘: 12×12px
- 스타일: SVG stroke 기반, fill 없음
- 활성 색상: 해당 텍스트 색상
- 비활성 색상: `text-muted`

> 아이콘 디자인 원본은 SVG 기준으로 관리하되,
> MFC 적용 시에는 PNG/BMP/ICO 등 런타임 자산 형식으로 변환하여 사용할 수 있다.

---

## MFC 구현 시 매핑 가이드

| 목업 요소 | MFC 구현 |
|-----------|----------|
| Title Bar | OS 기본 타이틀 바 |
| Menu Bar | CMenu 리소스 |
| Toolbar | CMFCToolBar + 아이콘 자산 |
| MDI Tabs | CMFCTabCtrl 또는 커스텀 탭 |
| Navigator | CDockablePane + CTreeCtrl |
| Center View | CListCtrl Report 모드 또는 커스텀 그리드 |
| Properties | CDockablePane + 커스텀 드로잉 |
| Output Pane | CDockablePane + CRichEditCtrl |
| Status Bar | CMFCStatusBar |

### 색상 적용 참고
```cpp
#define CLR_FRAME       RGB(0xE4, 0xE2, 0xDD)
#define CLR_SURFACE     RGB(0xF4, 0xF2, 0xEE)
#define CLR_WHITE       RGB(0xFD, 0xFC, 0xFA)
#define CLR_TEXT        RGB(0x2A, 0x29, 0x26)
#define CLR_TEXT_DIM    RGB(0x8A, 0x85, 0x7C)
#define CLR_ACCENT      RGB(0x4A, 0x6D, 0x8C)
#define CLR_ERROR       RGB(0xB8, 0x48, 0x40)
#define CLR_SUCCESS     RGB(0x5E, 0x85, 0x48)
#define CLR_WARNING     RGB(0xA0, 0x7E, 0x28)
```

### 리사이즈 구현 참고
```cpp
void CMainFrame::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
    lpMMI->ptMinTrackSize.x = 800;
    lpMMI->ptMinTrackSize.y = 600;
    CMDIFrameWndEx::OnGetMinMaxInfo(lpMMI);
}

m_wndNavigator.SetMinSize(CSize(120, 100));
m_wndProperties.SetMinSize(CSize(140, 100));
m_wndOutput.SetMinSize(CSize(100, 72));
```

---

## 다국어 문자열 테이블

모든 UI 문자열은 아래 기준을 따른다.
문자열 표의 ID는 논리 키 기준이며, MFC resource.h에서는 `IDS_` 접두사를 붙인 리소스 ID로 선언한다.

### String Table ID 접두사 규칙
| 접두사 | 영역 | 리소스 범위 |
|--------|------|-------------|
| `IDS_MENU_*` | 메뉴 바 | 10001 ~ 10099 |
| `IDS_TB_*` | 툴바 | 10101 ~ 10199 |
| `IDS_NAV_*` | 네비게이터 | 10201 ~ 10299 |
| `IDS_VIEW_*` | 뷰 헤더 | 10301 ~ 10399 |
| `IDS_PROP_*` | Properties | 10401 ~ 10499 |
| `IDS_LOG_*` | 로그 | 10501 ~ 10599 |
| `IDS_STATUS_*` | 상태바 | 10601 ~ 10699 |
| `IDS_COMMON_*` | 공통 | 10701 ~ 10799 |
| `IDS_LEVEL_*` | 로그 레벨 | 10801 ~ 10899 |

### 예시 논리 키
- `MENU_FILE`, `TB_OPEN`, `NAV_PIPELINE`, `VIEW_PREVIEW`
- `PROP_TITLE`, `LOG_FILE_OPENED`, `STATUS_READY`

### MFC 예시
```cpp
#define IDS_MENU_FILE       10001
#define IDS_TB_OPEN         10101
#define IDS_NAV_PIPELINE    10201
#define IDS_VIEW_PREVIEW    10301
#define IDS_PROP_TITLE      10401
#define IDS_LOG_FILE_OPENED 10501
#define IDS_STATUS_READY    10601

CString str;
str.LoadString(IDS_TB_OPEN);
```

### WebView2 예시 구조
```
web/
├── locale/
│   ├── ko.json
│   └── en.json
├── js/
│   └── i18n.js
```

### 다국어 적용 주의사항
- 레이아웃은 영어 길이 기준으로 여유를 확보한다
- 로그 메시지 placeholder는 이름 기반 포맷을 사용한다
- 숫자/날짜 포맷은 별도 포맷터에서 처리한다

---

## 목업 참조

이 skill과 함께 참조할 목업은 대화 내 `sagedash_erp_mockup_v3` 위젯을 기준으로 한다.
새 화면이나 Phase 진행에 따른 UI 변경 시, 이 디자인 시스템의 색상 / 레이아웃 / 상태 / 간격 / 다국어 규칙을 따른다.
